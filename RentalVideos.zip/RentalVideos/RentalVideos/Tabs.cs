﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentalVideos
{
    public partial class Tabs : Form
    {
        public Tabs()
        {
            InitializeComponent();
        }
        /// Show Customer Screen  click of button
        private void btnCustomers_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customers customers = new Customers();
            customers.ShowDialog();
        }
   
        /// Show Movies Screen  click of button
        private void btnMovies_Click(object sender, EventArgs e)
        {
            this.Hide();
            Movies _movies = new Movies();
            _movies.ShowDialog();
        }

  
        /// Show Movies Rental Screen on click of button
        private void btnRentalMovies_Click(object sender, EventArgs e)
        {
            this.Hide();
            MovieRental movieRental = new MovieRental();
            movieRental.ShowDialog();
        }
    }
}
